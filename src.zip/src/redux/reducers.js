import { combineReducers } from 'redux';


















const GlobalState = (combineReducers({}));
export default GlobalState;
